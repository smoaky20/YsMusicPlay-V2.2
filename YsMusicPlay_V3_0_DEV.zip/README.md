# Ys Music Play V3.0 — DEV

Application Android de lecture audio et vidéo, basée sur le projet V2.2 fourni.

## Modifications intégrées dans cette archive

- Version Android `3.0` (`versionCode 30`).
- Repeat cyclique : OFF → ONE → ALL → OFF, mémorisé dans les préférences.
- Shuffle Media3 conservé pour parcourir la liste en mode aléatoire.
- Pochette du morceau affichée en cercle, avec découpe circulaire réelle; disque animé pendant la lecture.
- Écran EQ accessible depuis Now Playing, avec presets Normal, Jazz, Rock, Bass et Treble et réglage manuel des bandes lorsqu'un effet Equalizer est disponible.
- Bass Boost conservé.
- Volume Booster via `LoudnessEnhancer` (gain modéré de +5 dB; le résultat dépend du téléphone et peut saturer selon le fichier).
- Effet « Alvin » approximé par une augmentation de vitesse et de hauteur (`PlaybackParameters`); ce n'est pas une séparation vocale ni un traitement de formants.
- Réglages de vitesse 0.75x, 1x, 1.25x, 1.5x et 2x.
- Thème sombre/clair et choix de cinq couleurs d'accent, mémorisés localement.
- Sélecteur Français/Malagasy; la langue par défaut est Français. La localisation de certains libellés reste partielle dans cette version DEV.
- Contraste amélioré dans les écrans File d'attente et Paroles; texte de paroles plus grand et plus lisible.
- Rotation vidéo manuelle par pas de 90° et option de rotation automatique par capteur.
- Pause audio lors de la réception du signal système `AUDIO_BECOMING_NOISY` (débranchement casque).
- Minuteur de veille conservé.

## Fonctionnalités non intégrées / non validées

Cette archive ne doit pas être considérée comme une version finale complète. Les éléments suivants ne sont pas inclus dans le code actuel :

- Recherche YouTube intégrée : nécessite une clé API officielle configurée et une intégration conforme aux conditions YouTube.
- Séparation IA Vocal/Instrumental : nécessite le choix et l'intégration d'un modèle compatible Android, puis des tests mémoire/performance sur l'appareil.
- Recherche automatique et synchronisation des paroles (LRC); l'écran Paroles permet actuellement la saisie manuelle.
- Gestes vidéo de luminosité/volume, verrouillage par balayage, et restauration automatique de la lecture au retour dans l'application.
- Vérification sur téléphone Android 10 réel.

## Compilation

GitHub Actions utilise Java 17 et Gradle 8.9. Une compilation verte vérifiera la compilation, pas le fonctionnement de chaque effet sur tous les téléphones.

Pour compiler : dépôt GitHub à la racine avec `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties` et `app/`. Lancer l'action **Build Ys Music Play V3.0**, puis télécharger l'artifact `YsMusicPlay-V3-APK`.
