# Ys Music Play V2.2 - TEST BUILD

Version de test issue du code source V2.1.

Modifications présentes dans cette version :
- Organisation des vidéos par dossier dans l'application.
- Affichage du nom du dossier parent uniquement.
- Arrêt du mode Repeat All.
- Suppression du libellé « Manaraka » dans la file de lecture.
- Version Android : 2.2 (versionCode 22).
- Nom de l'artifact GitHub Actions : YsMusicPlay-V2.2-APK.

IMPORTANT :
Cette archive est une version de test partielle, pas la version finale complète.
YouTube Search, séparation Vocal/Instrumental, Equalizer dans les lecteurs,
favoris, miniatures avancées, thèmes et autres fonctions prévues ne sont pas
encore intégrés ou validés.

Structure attendue : settings.gradle.kts et build.gradle.kts sont à la racine.
