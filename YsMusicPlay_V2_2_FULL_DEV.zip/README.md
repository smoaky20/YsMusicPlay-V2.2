# Ys Music Play V2.2

Application Android de lecture audio et vidéo.

## V2.2 — changements inclus dans cette archive
- Bibliothèque audio et vidéo via MediaStore.
- Vidéos regroupées par dossier, avec accès au contenu de chaque dossier.
- Miniatures vidéo depuis les URI MediaStore.
- Lecture audio/vidéo via Media3.
- Mode Favoris persisté localement.
- Écran Now Playing avec pochette et animation de disque.
- Accès à un égaliseur et à des presets Normal, Jazz, Rock, Bass et Treble depuis le lecteur audio.
- Sleep timer qui met le lecteur en pause à expiration.
- Navigation Retour gérée pour les écrans internes.
- Lecture sans Repeat All.
- Gradle 8.9 + Java 17 dans GitHub Actions.

## Limites à connaître
- YouTube Search n'est pas activé : il faut configurer un accès API officiel et respecter les règles YouTube.
- La séparation Vocal/Instrumental n'est pas incluse : elle nécessite un modèle IA de séparation audio et des tests de performance/mémoire sur appareil.
- Les commandes de luminosité/volume par gestes, verrouillage vidéo, rotation manuelle, thème clair/sombre et reprise Bluetooth doivent encore être intégrés et testés.
- Une compilation réussie sur GitHub ne remplace pas un test sur téléphone.
